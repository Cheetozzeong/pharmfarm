@echo off
setlocal
pushd "%~dp0"
set "PS_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS_EXE=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS_EXE%" goto POWERSHELL_NOT_FOUND
"%PS_EXE%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0PharmFarm-Agent.ps1" -Console -Resume -ConfigPath "%ProgramData%\PharmFarmAgent\agent.config.json"
set "AGENT_EXIT=%ERRORLEVEL%"
pause
exit /b %AGENT_EXIT%

:POWERSHELL_NOT_FOUND
echo Windows PowerShell was not found.
echo Check: %SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe
pause
exit /b 1
